export type RootStackParamList = {
  Welcome: undefined;
  Menu: undefined;
  Todo: undefined;
  Calc: undefined;
  Stopwatch: undefined;
  Counter: undefined;
};
